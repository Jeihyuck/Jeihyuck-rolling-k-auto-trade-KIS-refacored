"""Rolling K Auto Trade API package.  """
